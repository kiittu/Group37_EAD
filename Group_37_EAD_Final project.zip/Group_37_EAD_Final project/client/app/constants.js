export const BASE_API_URL = process.env.BASE_API_URL;

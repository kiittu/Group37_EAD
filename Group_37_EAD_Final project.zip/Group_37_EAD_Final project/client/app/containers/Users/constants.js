/*
 *
 * Users constants
 *
 */

export const FETCH_USERS = 'src/Users/FETCH_USERS';
